package com.example.cs360project2new;

import static com.example.cs360project2new.LoginActivity.KEY_USERNAME;
import static com.example.cs360project2new.LoginActivity.PREFS_NAME;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

// Inventory display screen for user to view, add,
// delete, and update the inventory list
public class Activity_display extends AppCompatActivity {

    // UI
    private RecyclerView recyclerView;
    private MaterialButton buttonAddItem;

    // Database handler
    private DatabaseHelper databaseHelper;

    // RecyclerView adapter
    private ItemAdapter itemAdapter;

    // user ID for user logged in
    private int currentUserId;

    // Session handling
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            EdgeToEdge.enable(this);
        } catch (NoClassDefFoundError | Exception e) {
            // silent catch
        }
        setContentView(R.layout.activity_data_display);

        // Toolbar setup
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.data_display), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Database and session initialization
        databaseHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // get ID for logged in user
        String username = sharedPreferences.getString(KEY_USERNAME, null);
        if (username != null) {
            currentUserId = databaseHelper.getUserId(username);
        } else {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // use functions for setup of UI and load items
        initializeViews();
        setupRecyclerView();
        loadItems();


    }

    // Initializing buttons and setting up click listeners
    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);

        buttonAddItem = findViewById(R.id.addItemBtn);

        if (buttonAddItem != null) {
            buttonAddItem.setOnClickListener(v -> showAddItemDialog());
        } else {
            Toast.makeText(this, "add button not found", Toast.LENGTH_SHORT).show();
        }
    }

    // Display all the items
    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemAdapter = new ItemAdapter();
        recyclerView.setAdapter(itemAdapter);
    }

    // Load all the items
    private void loadItems() {
        List<Item> items = databaseHelper.getAllItems(currentUserId);
        itemAdapter.setItems(items);
    }

    // Dialog for adding a new item
    private void showAddItemDialog() {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setTitle("Add a New Item");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.add_item, null);
        builder.setView(dialogView);

        // Connect UI to Java to take input given by user
        TextInputEditText editTextName = dialogView.findViewById(R.id.itemNameInput);
        TextInputEditText editTextDetails = dialogView.findViewById(R.id.itemDetailInput);
        TextInputEditText editTextQuantity = dialogView.findViewById(R.id.itemQuantityInput);
        TextInputEditText editTextDate = dialogView.findViewById(R.id.itemDateInput);


        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = editTextName.getText().toString().trim();
            String details = editTextDetails.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();
            String date = editTextDate.getText().toString().trim();

            if (!name.isEmpty()) {
                int quantity = quantityStr.isEmpty() ? 0 : Integer.parseInt(quantityStr);
                addNewItem(name, details, date, quantity);
            } else {
                Toast.makeText(Activity_display.this, "Item name needed", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    // Show appropriate dialog for editing item when edit button clicked
    private void showEditItemDialog(Item item) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setTitle("Edit item");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.add_item, null);
        builder.setView(dialogView);

        // Connecting UI to java to take input given by user
        TextInputEditText editTextName = dialogView.findViewById(R.id.itemNameInput);
        TextInputEditText editTextDetails = dialogView.findViewById(R.id.itemDetailInput);
        TextInputEditText editTextQuantity = dialogView.findViewById(R.id.itemQuantityInput);
        TextInputEditText editTextDate = dialogView.findViewById(R.id.itemDateInput);

        editTextName.setText(item.getName());
        editTextDetails.setText(item.getDetails());
        editTextQuantity.setText(String.valueOf(item.getQuantity()));
        editTextDate.setText(item.getDate());

        builder.setPositiveButton("Update", (dialog, which) -> {
            String name = editTextName.getText().toString().trim();
            String details = editTextDetails.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();
            String date = editTextDate.getText().toString().trim();

            if (!name.isEmpty()) {
                int quantity = quantityStr.isEmpty() ? 0 : Integer.parseInt(quantityStr);
                updateItem(item.getId(), name, details, date, quantity);
            } else {
                Toast.makeText(Activity_display.this, "Item name needed", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    // Add new item and refresh view
    private void addNewItem(String name, String details, String date, int quantity) {
        if (databaseHelper.addItem(name, details, date, quantity, currentUserId)) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            loadItems();

            // If low on stock, trigger SMS
            if (quantity <= 5) {
                sendLowStockAlert(name, quantity);
            }
        } else {
            Toast.makeText(this, "Failed to add", Toast.LENGTH_SHORT).show();
        }
    }

    // Update item details. If item quantity <= 5, send low stock SMS
    private void updateItem(int itemId, String name, String details, String date, int quantity) {
        if (databaseHelper.updateItem(itemId, name, details, date, quantity)) {
            Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
            loadItems();

            if (quantity <= 5) {
                sendLowStockAlert(name, quantity);
            }
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }

    // low stock SMS if permission is already granted
    private void sendLowStockAlert(String itemName, int itemQuantity) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            try {
                SmsManager smsManager = SmsManager.getDefault();
                String phoneNumber = "0123456789";
                String message = "NOTICE: " + itemName + " is running low on stock. Quantity is: " + itemQuantity;

                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Low stock alert sent via SMS", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }

        } else {
            // Permission not granted
            Toast.makeText(this, "SMS permission not granted. Enable it to receive alerts.", Toast.LENGTH_SHORT).show();
        }
    }

    // Confirm user really wants to delete item
    private void deleteItemWithConfirmation(Item item) {
        new MaterialAlertDialogBuilder(this).setTitle("Delete item")
                .setMessage("Do you really want to delete " + item.getName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (databaseHelper.deleteItem(item.getId())) {
                        Toast.makeText(Activity_display.this, "Item deleted", Toast.LENGTH_SHORT).show();
                        loadItems();
                    } else {
                        Toast.makeText(Activity_display.this, "Failed to delete", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // For displaying list of items
    private class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {
        private List<Item> items;

        public void setItems(List<Item> items) {
            this.items = items;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_data_row, parent, false);
            return new ItemViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
            Item item = items.get(position);
            holder.bind(item);
        }

        @Override
        public int getItemCount() {
            return items != null ? items.size() : 0;
        }


        // ViewHolder for performance
        class ItemViewHolder extends RecyclerView.ViewHolder {
            private TextView textViewName, textViewDetails, textViewQuantity, textViewDate;
            private MaterialButton buttonDelete;
            private MaterialCardView cardView;

            public ItemViewHolder(@NonNull View itemView) {
                super(itemView);

                textViewName = itemView.findViewById(R.id.ItemName);
                textViewDetails = itemView.findViewById(R.id.ItemDetails);
                textViewQuantity = itemView.findViewById(R.id.ItemQuantity);
                textViewDate = itemView.findViewById(R.id.ItemDate);
                buttonDelete = itemView.findViewById(R.id.Deletebtn);
                cardView = (MaterialCardView) itemView;

                setupClickListeners();
            }

            private void setupClickListeners() {
                cardView.setOnClickListener(v -> {
                    int position = getAbsoluteAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Item item = items.get(position);
                        showEditItemDialog(item);
                    }
                });

                buttonDelete.setOnClickListener(v -> {
                    int position = getAbsoluteAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Item item = items.get(position);
                        deleteItemWithConfirmation(item);
                    }
                });
            }

            public void bind(Item item) {
                textViewName.setText(item.getName());
                textViewDetails.setText(item.getDetails());
                textViewQuantity.setText("Quantity: " + item.getQuantity());
                textViewDate.setText(item.getDate());
            }
        }
    }

    // Handling logout button click
    public void onLogoutClicked(View view) {
        logoutUser();
    }

    // Logout and return to Login screen
    private void logoutUser() {
        // Show confirmation dialog
        new MaterialAlertDialogBuilder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Logout", (dialog, which) -> {
                    // Clear the login session
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.clear();
                    editor.apply();

                    // Navigate back to login screen
                    Intent intent = new Intent(Activity_display.this, LoginActivity.class);
                    startActivity(intent);
                    finish(); // Close current activity

                    Toast.makeText(Activity_display.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}