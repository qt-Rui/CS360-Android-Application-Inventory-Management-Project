package com.example.cs360project2new;

import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Handles Sms requests and permissions from user
// Display screen for permissions
public class SmsPermissionActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    // UI
    private Button buttonAcceptPermission, buttonDenyPermission, buttonContinueWithoutSms;
    private TextView textViewPermissionStatus;

    // SMS manager
    private SmsManager smsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // View and button handling initialization along with getting SMS manager
        initializeViews();
        setupClickListeners();
        smsManager = SmsManager.getDefault();

        // update the permission status
        updatePermissionStatus();

        // If redirected due to low stock, attempt to send alert
        checkForLowStockAlert();

    }

    // If item low on stock, attempt to send SMS
    private void checkForLowStockAlert() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("LOW_STOCK_ITEM")) {
            String itemName = intent.getStringExtra("LOW_STOCK_ITEM");
            int quantity = intent.getIntExtra("LOW_STOCK_QUANTITY", 0);

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
                sendLowStockAlert(itemName, quantity);
            }
        }
    }

    // Connect UI from layout to Java
    private void initializeViews() {
        buttonAcceptPermission = findViewById(R.id.accept_permission);
        buttonDenyPermission = findViewById(R.id.deny_permission);
        buttonContinueWithoutSms = findViewById(R.id.continue_without_sms);
        textViewPermissionStatus = findViewById(R.id.permission_status_unknown);
    }

    // assign actions to the buttons
    private void setupClickListeners() {
        buttonAcceptPermission.setOnClickListener(v -> requestSmsPermission());

        buttonDenyPermission.setOnClickListener(v -> {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            updatePermissionStatus();
        });

        buttonContinueWithoutSms.setOnClickListener(v -> navigateToDataDisplay());
    }

    // Request sms permission from user
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {
            onSmsPermissionGranted();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    // Handles the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onSmsPermissionGranted();
            } else {
                onSmsPermissionDenied();
            }
        }
    }

    // If sms granted, this is called
    private void onSmsPermissionGranted() {
        updatePermissionStatus();
        Toast.makeText(this, "SMS permission accepted", Toast.LENGTH_SHORT).show();

        sendWelcomeSms();
        navigateToDataDisplay();
    }

    // if sms is denied, this is called
    private void onSmsPermissionDenied() {
        updatePermissionStatus();
        Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
    }

    // Update on screen text for SMS permission
    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {
            textViewPermissionStatus.setText("PERMISSION STATUS: GRANTED");
        } else {
            textViewPermissionStatus.setText("PERMISSION STATUS: DENIED");
        }
    }

    // Send a intro message confirming the SMS
    private void sendWelcomeSms() {
        try {
            String phoneNumber = "0123456789";
            String message = "Thank you for accepting! SMS alerts are now on";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Welcome SMS sent", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "SMS failed to send: Permission denied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    // Send low stock alert silently
    public void sendLowStockAlert(String itemName, int itemQuantity) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {
            String phoneNumber = "0123456789";
            String message = "NOTICE: " + itemName + "is running low on stock. Quantity is: " + itemQuantity;

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            // leave empty for silent catch
        }
    }

    // Proceed to the main screen
    private void navigateToDataDisplay() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("hasAskedSmsPermission", true);
        editor.apply();

        Intent intent = new Intent(SmsPermissionActivity.this, Activity_display.class);
        startActivity(intent);
        finish();
    }
}
